function login(element) {
  element.innerText = "Logout"
}

function hide(element) {
  element.remove()
}

function like() {
  alert("Ninja was liked")
}
